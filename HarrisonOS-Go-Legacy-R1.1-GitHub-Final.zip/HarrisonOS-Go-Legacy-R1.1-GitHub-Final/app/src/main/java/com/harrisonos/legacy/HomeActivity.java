package com.harrisonos.legacy;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class HomeActivity extends Activity {
  private LinearLayout root;
  private float downY;
  private boolean quickOpen = false;
  private int pad = 8;

  public void onCreate(Bundle b) {
    super.onCreate(b);
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                         WindowManager.LayoutParams.FLAG_FULLSCREEN);
    showHome();
  }

  public void onBackPressed() {
    if (quickOpen) { showHome(); return; }
    showHome();
  }

  private TextView text(String s, int size) {
    TextView t = new TextView(this);
    t.setText(s);
    t.setTextSize(size);
    t.setTextColor(Color.WHITE);
    t.setGravity(Gravity.CENTER);
    t.setPadding(pad, pad, pad, pad);
    return t;
  }

  private Button button(String label, final Intent intent) {
    Button b = new Button(this);
    b.setText(label);
    b.setTextSize(15);
    b.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) { safeStart(intent); }
    });
    return b;
  }

  private Button actionButton(String label, final int action) {
    Button b = new Button(this);
    b.setText(label);
    b.setTextSize(14);
    b.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) { performQuickAction(action); }
    });
    return b;
  }

  private void safeStart(Intent i) {
    try { startActivity(i); }
    catch (Exception e) { showMessage("That app is not available on this phone."); }
  }

  private ScrollView baseScreen() {
    ScrollView sc = new ScrollView(this);
    sc.setBackgroundColor(Color.rgb(8,16,24));
    sc.setOnTouchListener(new View.OnTouchListener() {
      public boolean onTouch(View v, MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) downY = e.getY();
        if (e.getAction() == MotionEvent.ACTION_UP) {
          float dy = e.getY() - downY;
          if (!quickOpen && downY < 90 && dy > 90) { showQuickSettings(); return true; }
          if (quickOpen && dy < -90) { showHome(); return true; }
        }
        return false;
      }
    });
    return sc;
  }

  private void showHome() {
    quickOpen = false;
    ScrollView sc = baseScreen();
    root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(10,8,10,10);
    root.setBackgroundColor(Color.rgb(8,16,24));
    sc.addView(root);

    String tm = new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date());
    String date = new SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(new Date());
    root.addView(text("HARRISON OS", 18));
    root.addView(text("GO LEGACY R1", 12));
    root.addView(text(tm, 34));
    root.addView(text(date, 13));
    root.addView(text("Swipe down from the top for Quick Settings", 11));

    root.addView(button("Phone", new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))));
    root.addView(button("Messages", new Intent(Intent.ACTION_VIEW, Uri.parse("sms:"))));
    root.addView(button("Camera", new Intent("android.media.action.IMAGE_CAPTURE")));
    root.addView(button("Internet", new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.com"))));
    root.addView(button("Settings", new Intent(Settings.ACTION_SETTINGS)));

    Button apps = new Button(this);
    apps.setText("Apps");
    apps.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) { showApps(); }
    });
    root.addView(apps);
    root.addView(text("No root • No system files changed • HTC Sense stays installed", 10));
    setContentView(sc);
  }

  private void showQuickSettings() {
    quickOpen = true;
    ScrollView sc = baseScreen();
    LinearLayout p = new LinearLayout(this);
    p.setOrientation(LinearLayout.VERTICAL);
    p.setPadding(10,10,10,10);
    p.setBackgroundColor(Color.rgb(18,28,38));
    sc.addView(p);

    String tm = new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date());
    p.addView(text("QUICK SETTINGS", 18));
    p.addView(text(tm, 28));
    p.addView(actionButton("Wi-Fi: toggle", 1));
    p.addView(actionButton("Bluetooth: toggle", 2));
    p.addView(actionButton("Sound / Silent", 3));
    p.addView(actionButton("Brightness", 4));
    p.addView(button("Display & rotation settings", new Intent(Settings.ACTION_DISPLAY_SETTINGS)));
    p.addView(button("Wireless settings", new Intent(Settings.ACTION_WIRELESS_SETTINGS)));

    Button close = new Button(this);
    close.setText("Close Quick Settings");
    close.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) { showHome(); }
    });
    p.addView(close);
    p.addView(text("Swipe up to close", 11));
    setContentView(sc);
  }

  private void performQuickAction(int action) {
    try {
      if (action == 1) {
        WifiManager wm = (WifiManager)getSystemService(Context.WIFI_SERVICE);
        if (wm != null) {
          boolean next = !wm.isWifiEnabled();
          wm.setWifiEnabled(next);
          showMessage(next ? "Wi-Fi turning on" : "Wi-Fi turning off");
        }
      } else if (action == 2) {
        BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();
        if (ba == null) showMessage("Bluetooth is not available.");
        else if (ba.isEnabled()) { ba.disable(); showMessage("Bluetooth turning off"); }
        else { ba.enable(); showMessage("Bluetooth turning on"); }
      } else if (action == 3) {
        AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        if (am != null) {
          if (am.getRingerMode() == AudioManager.RINGER_MODE_NORMAL) {
            am.setRingerMode(AudioManager.RINGER_MODE_SILENT);
            showMessage("Silent mode");
          } else {
            am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
            showMessage("Sound on");
          }
        }
      } else if (action == 4) {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        if (lp.screenBrightness < 0.35f || lp.screenBrightness < 0) lp.screenBrightness = 0.65f;
        else if (lp.screenBrightness < 0.8f) lp.screenBrightness = 1.0f;
        else lp.screenBrightness = 0.25f;
        getWindow().setAttributes(lp);
        showMessage("Brightness changed");
      }
    } catch (Exception e) {
      showMessage("This setting is controlled by Android on this phone.");
    }
  }

  private void showApps() {
    quickOpen = false;
    ScrollView sc = baseScreen();
    LinearLayout list = new LinearLayout(this);
    list.setOrientation(LinearLayout.VERTICAL);
    list.setPadding(10,10,10,10);
    list.setBackgroundColor(Color.rgb(8,16,24));

    list.addView(text("APPS", 20));
    Button home = new Button(this);
    home.setText("Back to Home");
    home.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) { showHome(); }
    });
    list.addView(home);

    PackageManager pm = getPackageManager();
    Intent q = new Intent(Intent.ACTION_MAIN);
    q.addCategory(Intent.CATEGORY_LAUNCHER);
    java.util.List apps = pm.queryIntentActivities(q, 0);
    for (int x = 0; x < apps.size(); x++) {
      final android.content.pm.ResolveInfo ri = (android.content.pm.ResolveInfo)apps.get(x);
      Button b = new Button(this);
      b.setText(ri.loadLabel(pm));
      b.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
          Intent launch = getPackageManager().getLaunchIntentForPackage(ri.activityInfo.packageName);
          if (launch != null) safeStart(launch);
        }
      });
      list.addView(b);
    }
    sc.addView(list);
    setContentView(sc);
  }

  private void showMessage(String s) {
    android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show();
  }
}
