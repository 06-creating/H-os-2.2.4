HARRISON OS GO LEGACY R1.1 — BUILD-READY PROJECT

Purpose
- Lightweight Home/launcher overlay for Android 2.2 (API 8) HTC devices.
- Does NOT replace Android, root the phone, delete HTC Sense, or modify the system partition.

Fast phone-only build
1. On your newer Android phone, open this whole folder as a Gradle Android project in an Android IDE that supports Gradle builds.
2. Let the IDE install/sync the required SDK/build components if asked.
3. Choose Build APK / Assemble Debug.
4. The expected output is usually:
   app/build/outputs/apk/debug/app-debug.apk
5. Transfer that APK to the HTC by your data cable / USB adapter or microSD.
6. On the HTC enable Settings > Applications > Unknown sources.
7. Install the APK.
8. FIRST TEST: open Harrison OS from the app list. Do NOT set it as the default Home yet.
9. Test Phone, Messages, Camera, Internet, Settings, Apps, swipe-down Quick Settings, Back and Home.
10. Only after those work, press Home and choose Harrison OS. Avoid choosing "use by default" until you are satisfied.

Safety fallback
- HTC Sense remains installed underneath.
- No root permission is used.
- No boot receiver or background service is included.
- No device-admin permission is included.

Project compatibility
- Minimum Android: 2.2 / API 8
- Target Android: API 8
- Java source level: 7
- No AndroidX dependency
- No third-party libraries

IMPORTANT
A successful build on the newer phone does not by itself prove every HTC-specific app shortcut works. The old HTC is still the final real-device compatibility test. Keeping HTC Sense as the fallback makes the first test low-risk.
