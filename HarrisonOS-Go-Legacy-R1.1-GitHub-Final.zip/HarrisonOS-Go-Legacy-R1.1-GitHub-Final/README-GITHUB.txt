HARRISON OS GO LEGACY R1.1 - GITHUB CLOUD BUILD
================================================

This project is prepared for GitHub Actions so you can build the APK from a phone browser.

FAST PHONE-ONLY STEPS
---------------------
1. Sign in to github.com in Chrome.
2. Create a NEW repository. A private repository is fine.
3. Open the repository, choose Add file > Upload files.
4. IMPORTANT: unzip this package first, then upload the CONTENTS of the folder so that
   build.gradle, settings.gradle, app, and .github are at the repository's top level.
5. Commit/upload the files to the main branch.
6. Open the Actions tab.
7. Choose "Build Harrison OS APK".
8. If it has not started automatically, choose "Run workflow".
9. Wait for the build to show a green tick.
10. Open the finished run and download the artifact named:
      HarrisonOS-Go-Legacy-R1.1-APK
11. GitHub downloads an artifact ZIP. Unzip it. Inside is:
      HarrisonOS-Go-Legacy-R1.1.apk

WHAT THE CLOUD CHECKS
---------------------
- Compiles the Android app using Gradle.
- Confirms an APK was actually generated.
- Checks that the APK ZIP structure is valid.
- Reads the APK manifest and requires minSdk 8 (Android 2.2/Froyo).
- Verifies the APK signature.
- Requires APK Signature Scheme v1/JAR signing, which old Android versions need.

SAFE FIRST HTC TEST
-------------------
Do NOT select Harrison OS as the permanent/default Home app on the first launch.
Install it normally, open Harrison OS manually, and test:
- Home screen
- Apps drawer
- Phone shortcut
- Messages shortcut
- Camera shortcut
- Settings shortcut
- Swipe down from the top for Quick Settings
- Wi-Fi/Bluetooth/sound/brightness controls
- Back button and physical Home button

Harrison OS is a launcher. It does not root the HTC, erase HTC Sense, or modify Android
system files. HTC Sense remains installed as the fallback home screen.

UPDATES
-------
Future versions can keep the same applicationId (com.harrisonos.legacy) and signing key
and increase versionCode/versionName. For initial testing this workflow makes a debug-signed
APK. Before relying on in-place updates long term, create and preserve one release signing
key and switch the workflow to release signing.
